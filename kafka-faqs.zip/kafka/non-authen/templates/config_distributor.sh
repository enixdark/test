#!/bin/bash

source .env
echo "Getting env parameters..."
for var in $(grep -oE '^\s*([^#]\S*)\s*=' .env | sed 's/=//'); do echo $var=${!var} && export $var=${!var}; done

echo "Templating config files..."
envsubst < server.properties.tpl > ../broker/server.properties
envsubst < zoo.cfg.tpl > ../zookeeper/conf/zoo.cfg

tree -L 1 ../broker
tree -L 1 ../zookeeper/conf
