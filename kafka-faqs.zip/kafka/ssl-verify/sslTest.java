import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLContext;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.TrustManagerFactory;
import java.security.KeyStore;
import java.io.FileInputStream;
import java.io.File;
import java.security.SecureRandom;

public class sslTest {

    private static final String KEYSTORE_PATH = System.getProperty("keystorePath");
    private static final String TRUSTSTORE_PATH = System.getProperty("truststorePath");
    private static final String STORE_PASSWORD = "Tpb@123";  // Use your keystore and truststore password

    public static void main(String[] args) {
	System.out.println("Keystore path: " + new File(KEYSTORE_PATH).getAbsolutePath());
	System.out.println("Truststore path: " + new File(TRUSTSTORE_PATH).getAbsolutePath());
        try {
            // Load the keystore
            KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
            try (FileInputStream keystoreFis = new FileInputStream(KEYSTORE_PATH)) {
                keystore.load(keystoreFis, STORE_PASSWORD.toCharArray());
            }

            // Load the truststore
            KeyStore truststore = KeyStore.getInstance(KeyStore.getDefaultType());
            try (FileInputStream truststoreFis = new FileInputStream(TRUSTSTORE_PATH)) {
                truststore.load(truststoreFis, STORE_PASSWORD.toCharArray());
            }

            // Set up key manager factory
            KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            keyManagerFactory.init(keystore, STORE_PASSWORD.toCharArray());

            // Set up trust manager factory
            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            trustManagerFactory.init(truststore);

            // Initialize SSLContext
            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(keyManagerFactory.getKeyManagers(), trustManagerFactory.getTrustManagers(), new SecureRandom());

            // Create server socket
            SSLServerSocketFactory ssf = sslContext.getServerSocketFactory();
            try (SSLServerSocket serverSocket = (SSLServerSocket) ssf.createServerSocket(8443)) {  // Port 8443 can be any free port
                System.out.println("SSL server socket created successfully!");
                // Optionally wait for connections to test actual data transfer
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
