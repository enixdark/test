#!/bin/bash

check_zookeeper_installed () {
    if [[ -d "/opt/zookeeper" && -f "/opt/zookeeper/bin/zkServer.sh" ]]; then
        echo "ZooKeeper seems to be installed."
        /opt/zookeeper/bin/zkServer.sh version
    else
        echo -e "\033[0;31mZooKeeper is not installed. Proceeding with installation...\n\033[0m"
        install_zookeeper
    fi
}

install_zookeeper () {
    read -p "Do you want to install ZooKeeper server? [Y/n] " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "Start installing ZooKeeper..."
        ZOOKEEPER_HOME=/opt/zookeeper
        mkdir -p /opt/zookeeper
        tar -xzvf ./apache-zookeeper-3.8.4-bin.tar.gz -C /opt/zookeeper --strip-components=1

        # Append to .bashrc and source it to update the environment
        source ~/.bashrc
        if ! grep -q "ZOOKEEPER_HOME" ~/.bashrc; then
        tee -a ~/.bashrc << END
export ZOOKEEPER_HOME=/opt/zookeeper
export PATH="$ZOOKEEPER_HOME/bin:$PATH"
END
        
        fi
        echo "ZooKeeper installation completed."
    else
        printf "\033[0;31m>> User refused to install ZooKeeper. Abort...\n\033[0m"
        exit 0
    fi
}

printf "\033[0;34mChecking for ZooKeeper installation...\n\033[0m"
check_zookeeper_installed
