#!/bin/bash

#!/bin/bash

# Load environment variables from .env file
source .env
echo "Getting env parameters..."
mkdir -p /opt/kafka/config/sasl-scram
mkdir -p /opt/kafka/config/sasl-scram/ssl
mkdir -p /opt/zookeeper/conf/sasl-scram
# Iterate over variables in the .env file and export them
for var in $(grep -oE '^\s*([^#]\S*)\s*=' .env | sed 's/=//'); do
    echo "$var=${!var}" && export "$var=${!var}"
done

# Function to back up the existing configuration files
backup_file() {
    local file_path="$1"
    if [[ -f "$file_path" ]]; then
        local backup_path="${file_path}.bak_$(date +%Y%m%d_%H%M%S)"
        echo "Backing up $file_path to $backup_path"
        cp "$file_path" "$backup_path"
    else
        echo "No existing $file_path found, skipping backup."
    fi
}

echo "Templating config files..."

# Backup and generate Kafka server.properties
backup_file "/opt/kafka/config/server.properties"
backup_file "/opt/kafka/config/sasl-scram/server.properties"
backup_file "/opt/kafka/config/sasl-scram/kafka_server_jaas.conf"
envsubst < kafka_server_jaas.conf.tpl > /opt/kafka/config/sasl-scram/kafka_server_jaas.conf


if [[ "${MODE}" == "cluster" ]]; then
    # Use the cluster configuration template
    if [[ "${SALS}" == "false" ]]; then
        envsubst < kafka_broker.properties.tpl > /opt/kafka/config/server.properties
    else
        envsubst < kafka_broker.sasl.properties.tpl > /opt/kafka/config/sasl-scram/server.properties
    fi
else
    # Use the standalone configuration template
    envsubst < kafka_broker.standalone.properties.tpl > /opt/kafka/config/server.properties
    if [[ "${SALS}" == "false" ]]; then
        envsubst < kafka_broker.standalone.properties.tpl > /opt/kafka/config/server.properties
    else
        envsubst < kafka_broker.sasl.standalone.properties.tpl > /opt/kafka/config/sasl-scram/server.properties
    fi
fi


# Backup and generate Kafka server.properties
# backup_file "/opt/kafka/config/kafka_runtime.cfg"
envsubst < kafka_runtime.cfg.tpl > /opt/kafka/config/kafka_runtime.cfg
envsubst < kafka_runtime.sasl.cfg.tpl > /opt/kafka/config/sasl-scram/kafka_runtime.cfg

# Backup and generate ZooKeeper zoo.cfg

backup_file "/opt/zookeeper/conf/zoo.cfg"
backup_file "/opt/zookeeper/conf/sasl-scram/zoo.cfg"

if [[ "${MODE}" == "cluster" ]]; then
    # Use the cluster configuration template
    if [[ "${SALS}" == "false" ]]; then
        envsubst < zoo.cfg.tpl > /opt/zookeeper/conf/zoo.cfg
    else
        envsubst < zoo.sasl.cfg.tpl > /opt/zookeeper/conf/sasl-scram/zoo.cfg
    fi
else
    # Use the standalone configuration template
    if [[ "${SALS}" == "false" ]]; then
        envsubst < zoo.standalone.cfg.tpl > /opt/zookeeper/conf/zoo.cfg
    else
        envsubst < zoo.standalone.cfg.tpl > /opt/zookeeper/conf/sasl-scram/zoo.cfg
    fi
fi


backup_file "/opt/zookeeper/conf/zookeeper_jaas.conf"
backup_file "/opt/zookeeper/conf/sasl-scram/zookeeper_jaas.conf"
envsubst < zookeeper_jaas.conf.tpl > /opt/zookeeper/conf/zookeeper_jaas.conf
envsubst < zookeeper_jaas.conf.tpl > /opt/zookeeper/conf/sasl-scram/zookeeper_jaas.conf

# backup_file "/opt/zookeeper/conf/zookeeper_runtime.cfg"
if [[ "${SALS}" == "false" ]]; then
    envsubst < zookeeper_runtime.cfg.tpl > /opt/zookeeper/conf/zookeeper_runtime.cfg
else
    envsubst < zookeeper_runtime.sasl.cfg.tpl > /opt/zookeeper/conf/sasl-scram/zookeeper_runtime.cfg
fi

echo "Configuration files templated and backups created."

# tree -L 1 ../broker
# tree -L 1 ../zookeeper/conf
