#!/bin/bash

# Define the source and destination paths
KAFKA_SERVICE_SOURCE="./systemd/kafka-sasl.service"
ZK_SERVICE_SOURCE="./systemd/zk-sasl.service"
SYSTEMD_PATH="/etc/systemd/system/"

# Function to copy services and start them
copy_and_start_services() {
    echo "Copying Kafka and ZooKeeper SASL service files to systemd..."

    # Copy Kafka service file
    if [[ -f "$KAFKA_SERVICE_SOURCE" ]]; then
        sudo cp "$KAFKA_SERVICE_SOURCE" "$SYSTEMD_PATH"
        echo "Kafka SASL service file copied."
    else
        echo "Kafka SASL service file not found."
        exit 1
    fi

    # Copy ZooKeeper service file
    if [[ -f "$ZK_SERVICE_SOURCE" ]]; then
        sudo cp "$ZK_SERVICE_SOURCE" "$SYSTEMD_PATH"
        echo "ZooKeeper SASL service file copied."
    else
        echo "ZooKeeper SASL service file not found."
        exit 1
    fi

    # Reload systemd to register new service files
    echo "Reloading systemd daemon..."
    sudo systemctl daemon-reload

    # Enable and start the Kafka service
    echo "Starting Kafka SASL service..."
    sudo systemctl enable kafka-sasl.service
    sudo systemctl start kafka-sasl.service

    # Enable and start the ZooKeeper service
    echo "Starting ZooKeeper SASL service..."
    sudo systemctl enable zk-sasl.service
    sudo systemctl start zk-sasl.service

    echo "Kafka and ZooKeeper SASL services have been started."
}

# Execute the function
copy_and_start_services