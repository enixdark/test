#!/bin/bash

install_jdk () {
	read -p "Do you want to install jdk-11" -n 1 -r
	echo
	if [[ ! $REPLY =~ ^[Yy]$ ]]; then
		JAVA_HOME=/opt/jres/jdk-11
		echo start installing jdk-11
		mkdir -p /opt/jres/
		tar -xzvf ./openjdk-11_linux-x64_bin.tar.gz -C /opt/jres/
		source ~/.bashrc
		if ! grep -q "JAVA_HOME" ~/.bashrc; then
		tee -a ~/.bashrc << END
		export JAVA_HOME=/opt/jres/jdk-11
		export PATH="$JAVA_HOME/bin:$PATH"
END
		fi
	else printf "\033[0;31m>> User refuse to install JRE11, Abort...\n\033[0m" && exit 0
	fi

}

printf "\033[0;34mChecking for prerequisites...\n\033[0m"

printf "\033[0;32m>> Java JRE 11: \n\033[0m"
java -version || { echo -e "\033[0;31mNo Java JREs found\n\033[0m"; install_jdk; }
