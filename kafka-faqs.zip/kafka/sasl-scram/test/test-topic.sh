
       	#--broker-list 10.1.54.105:9093,10.202.14.27:9093,10.6.14.81:9093 \
/home/quantri/kafka_2.12-3.6.1/bin/kafka-console-producer.sh \
       	--broker-list 10.202.14.27:9093 \
       	--producer.config ssl-test-config.properties \
    	--topic scram512-test-topic

#/home/quantri/kafka_2.12-3.6.1/bin/kafka-console-producer.sh \
#        --bootstrap-server 10.1.54.105:9092,10.202.14.27:9092,10.6.14.81:9092 \
#        --topic test-topic

#/home/quantri/kafka_2.12-3.6.1/bin/kafka-topics.sh \
#       	--bootstrap-server=10.1.54.105:9093,10.202.14.27:9093,10.6.14.81:9093 \
#       	--command-config ssl-test-config.properties \
#	--delete scram512-test-topic
