
/home/quantri/kafka_2.12-3.6.1/bin/kafka-console-producer.sh \
       	--broker-list 10.202.14.27:9093 \
       	--producer.config ssl-test-config.properties \
    	--topic kafka_perf_test 
