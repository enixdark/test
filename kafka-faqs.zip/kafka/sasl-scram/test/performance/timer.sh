START=$(date +%s%3N)
# do something #######################

"$@" &> /dev/null

#######################################
END=$(date +%s%3N)
echo "Message produced in $(($END-$START))ms"
