#!/bin/bash

BROKER=10.1.54.105:9092,10.202.14.27:9092,10.6.14.81:9092
#BROKER=10.1.54.105:9093,10.202.14.27:9093,10.6.14.81:9093
TOPICS=(${1//,/ })
NUM_MESSAGES=$2

INSTANCE=${3:-1}

# Produce messages to the specified topics
for TOPIC in "${TOPICS[@]}"
do
    for ((i=1; i<=NUM_MESSAGES; i++))
    do
        # Include the current timestamp in the message
        TIMESTAMP=$(date +%s%3N) # Current time in milliseconds
        echo "Instance $INSTANCE sending Message $i with timestamp $TIMESTAMP" | /home/quantri/kafka_2.12-3.6.1/bin/kafka-console-producer.sh --broker-list $BROKER --topic $TOPIC # --producer.config ssl-test-config.properties
    done 
done
