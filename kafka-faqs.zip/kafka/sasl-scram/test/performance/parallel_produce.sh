#!/bin/bash

if [ $# -eq 0 ]; then
    echo "Usage: $0 <number-of-iterations>"
    exit 1
fi

num_iterations=$1
target_topic=${2:-kafka_perf_test}
msg_number=${3:-100}
# Reset the SECONDS variable
ST=$(date +%s%3N)


# Start the tasks in parallel
for i in $(seq 1 $num_iterations); do
    ./producer.sh $target_topic $msg_number $i &
done

# Wait for all background jobs to finish
wait

# Calculate elapsed time
EN=$(date +%s%3N)
elapsed=$(($EN-$ST))

echo "Total elapsed time: $elapsed ms"
