#!/bin/bash

printf "%-15s\t%-15s\t%-15s\n" "PartitionID" "OffsetID" "Latency" 
 /home/quantri/kafka_2.12-3.6.1/bin/kafka-console-consumer.sh \
	 --bootstrap-server 10.1.54.105:9093,10.202.14.27:9093,10.6.14.81:9093 \
	 --topic kafka_perf_test \
	 --consumer.config ssl-test-config.properties \
	 --group PERF_TEST \
	 --formatter kafka.tools.DefaultMessageFormatter \
	 --property print.partition=true --property print.offset=true --property key.separator="," | while IFS=',' read PARTITION OFFSET VALUE
do
    	PARTITION_ID="${PARTITION#*:}"
    	OFFSET_ID="${OFFSET#*:}"
       	MESSAGE_TIMESTAMP=$(echo "$VALUE" | grep -oP '\d+$')
       	CURRENT_TIMESTAMP=$(date +%s%3N)
       	LATENCY=$((CURRENT_TIMESTAMP - MESSAGE_TIMESTAMP)) 
	printf "%-15d\t%-15d\t%-15s\n" "$PARTITION_ID" "$OFFSET_ID" "$LATENCY ms"
done
