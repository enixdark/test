#!/bin/bash

OUT_DIR=ssl_pack_$(date +%Y%m%d)

mkdir -p $OUT_DIR

echo "Generating rootca..."
openssl genrsa -out $OUT_DIR/rootca.key 4096
openssl req -x509 -new -nodes -key $OUT_DIR/rootca.key -sha256 -days 1000 -out $OUT_DIR/rootca.crt -config configs/rootca.conf

echo "Creating truststore with rootca..."
keytool -keystore $OUT_DIR/kafka.truststore.jks -storetype JKS -import -file $OUT_DIR/rootca.crt -storepass Tpb@123 -alias KMS-RootCA -noprompt

# Generate client keys
echo "Generating broker certificate & sign with rootca..."
NODES=(apkmsnode1-1uv apkmsnode1-2uv apkmsnode1-3uv)
for NODE_NAME in "${NODES[@]}"; do
	echo "Start signing broker $NODE_NAME"
	openssl genrsa -out $OUT_DIR/$NODE_NAME.key 4096
	openssl req -new -key $OUT_DIR/$NODE_NAME.key -out $OUT_DIR/$NODE_NAME.csr -config configs/brokercsr.conf -extensions v3_req
	openssl x509 -req -in $OUT_DIR/$NODE_NAME.csr -CA $OUT_DIR/rootca.crt -CAkey $OUT_DIR/rootca.key -CAcreateserial -out $OUT_DIR/$NODE_NAME.crt -days 1000 -sha256 -extfile configs/brokercsr.conf -extensions v3_req -passin pass:Tpb@123

	echo "> Verify certs:"
	openssl verify -CAfile $OUT_DIR/rootca.crt $OUT_DIR/$NODE_NAME.crt
	openssl x509 -in $OUT_DIR/$NODE_NAME.crt -text -noout | grep -A 1 "Subject Alternative Name"

	echo "Creating keystore with signed key..."
	echo "Importing CA cert to establish trust..."
    	keytool -keystore $OUT_DIR/$NODE_NAME.keystore.jks -storetype JKS -alias kms-rootca -importcert -file $OUT_DIR/rootca.crt -storepass Tpb@123 -noprompt
    	# Import the private key and signed certificate into the keystore
    	openssl pkcs12 -export -in $OUT_DIR/$NODE_NAME.crt -inkey $OUT_DIR/$NODE_NAME.key -out $OUT_DIR/$NODE_NAME.p12 -name $NODE_NAME -CAfile $OUT_DIR/rootca.crt -caname kms-rootca -password pass:Tpb@123
    	keytool -importkeystore -destkeystore $OUT_DIR/$NODE_NAME.keystore.jks -deststoretype JKS -deststorepass Tpb@123 -destkeypass Tpb@123 -srckeystore $OUT_DIR/$NODE_NAME.p12 -srcstoretype PKCS12 -srcstorepass Tpb@123 -alias $NODE_NAME
	
	keytool -list -keystore $OUT_DIR/$NODE_NAME.keystore.jks -storepass Tpb@123
	echo "============================="
done



