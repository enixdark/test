setenforce 0
sed -i --follow-symlinks 's/SELINUX=enforcing/SELINUX=disabled/g' /etc/sysconfig/selinux
systemctl stop firewalld
systemctl disable firewalld
swapoff -a
sed -e '/swap/ s/^#*/#/' -i /etc/fstab

cd /home/quantri/rke2-artifacts
mkdir -p /data
cd /home/quantri
cp -r certs/ /data/

INSTALL_RKE2_ARTIFACT_PATH=/home/quantri/rke2-artifacts sh install.sh
mkdir -p /etc/rancher/rke2
touch /etc/rancher/rke2/config.yaml
#cat > /etc/rancher/rke2/config.yaml <<-EOF
#server: https://10.6.22.55:9345
#token: K10d753f54d09ba83fd2305a7c60d0c071982383cc226543dbd2f2e7cd1b3085581::server:a8971b1ce89dcd20d1ad051b94832f34
#EOF

cat > /etc/rancher/rke2/config.yaml <<-EOF
server: https://10.210.22.96:9345
token: K10d753f54d09ba83fd2305a7c60d0c071982383cc226543dbd2f2e7cd1b3085581::server:a8971b1ce89dcd20d1ad051b94832f34
EOF

echo "10.210.22.91  docker-registry.tpb.vn" >> /etc/hosts
#echo "10.6.22.56  docker-registry.tpb.vn" >> /etc/hosts
mkdir -p /etc/docker/certs.d/docker-registry.tpb.vn\:5000
touch /etc/docker/certs.d/docker-registry.tpb.vn\:5000/ca.crt
cat > /etc/docker/certs.d/docker-registry.tpb.vn\:5000/ca.crt <<-EOF
-----BEGIN CERTIFICATE-----
MIIDmDCCAoCgAwIBAgIUGLd0JXth/KTV2Ylq8Afp+GFaan8wDQYJKoZIhvcNAQEL
BQAwgYQxCzAJBgNVBAYTAlZOMQswCQYDVQQIDAJITjELMAkGA1UEBwwCSE4xDDAK
BgNVBAoMA1RQQjEMMAoGA1UECwwDVFBCMR8wHQYDVQQDDBZkb2NrZXItcmVnaXN0
cnkudHBiLnZuMR4wHAYJKoZIhvcNAQkBFg9lYml0QHRwYi5jb20udm4wHhcNMjIx
MTExMTAzNzM3WhcNMzIxMTA4MTAzNzM3WjBWMQswCQYDVQQGEwJWTjELMAkGA1UE
CAwCSE4xCzAJBgNVBAcMAkhOMQwwCgYDVQQLDANUUEIxHzAdBgNVBAMMFmRvY2tl
ci1yZWdpc3RyeS50cGIudm4wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
AQDhw0ZCaidFJFP1SLsV+Iwk0CLt020jZ+p950Qffe08BR5okcEOoJd1lDCPP8ZV
VSDeqwkM8WhGb1YM9WoSSu7S+qElQ/7bFe4mQ9kxw+XkZ6rF8jcPf4mMu9jSwdrD
DW+lnqjFYfUecHCJCeXTQ6cqe6KfVXkHK5Gzwjz0+n8fC48pIEwIpD5Ni90Erf99
59muaXgjzPLblxAlW2KZquO/Ic17GYxcB35rHOTPovhH285GjcNMzKkZmemDxZzb
+BAGRIHbjo5szeGeS7/PheXFJa1iqMEYsyTjf+q27hjQiERjK89u84DjRb2WaZtN
xbrFrq6HEXbbCPSYulBAFj6hAgMBAAGjLzAtMAkGA1UdEwQCMAAwCwYDVR0PBAQD
AgXgMBMGA1UdEQQMMAqCCCoudHBiLnZuMA0GCSqGSIb3DQEBCwUAA4IBAQAPRaL5
DtgXKh22bsrHGqSBeT5gs7O0NBvfRyBBtDO7ZRfUCnXjQ22JicjCaF7YQ5EFPSgK
UJiAPoEqeJRuEq+qWu8jByRcN5krrU5KHrihJTdu1VSHNTQthW3ulL59DvWylQl5
eY4QN8CKer6Ssb0yG6JSwuORNiDqX6mvRtV6lCLLCY2RsFXwUhZv+YbPGABpYxM2
tJgJY680symICPedg3tHD4PZ/3YpYGqDU0l5Ol20cH9WvHr4ybtP7XMGIGi1h+s4
JNQXDeEXG7B53Dx2Ntk9CD0UsjieW7R8gT3AqlJXvKlXj2f8CpWG2TSyWbyK2FTC
lkEp39rNmYTDybLY
-----END CERTIFICATE-----
EOF
systemctl restart docker

touch /etc/rancher/rke2/registries.yaml
cat > /etc/rancher/rke2/registries.yaml <<-EOF
mirrors:
  docker.io:
    endpoint:
      - "https://docker-registry.tpb.vn:5000"
  k8s.gcr.io:
    endpoint:
      - "https://docker-registry.tpb.vn:5000"
  nvcr.io:
    endpoint:
      - "https://docker-registry.tpb.vn:5000"
  quay.io:
    endpoint:
      - "https://docker-registry.tpb.vn:5000"
  registry.k8s.io:
    endpoint:
      - "https://docker-registry.tpb.vn:5000"
configs:
  "docker-registry.tpb.vn:5000":
    tls:
	  insecure_skip_verify: true
      #cert_file:            /data/certs/docker-registry.crt
      #key_file:             /data/certs/docker-registry.key
      #ca_file:              /data/certs/rootCA.pem
EOF
systemctl enable --now rke2-agent
systemctl start rke2-agent
