#!/bin/bash

tar -xzvf docker.tgz

cp docker/* /usr/local/bin

# avoid error docker.socket when need to out rsyslog
mkdir -p /var/lib/rsyslog

# add docker group to start docker.socket
groupadd docker 

cp docker.service /usr/lib/systemd/system/docker.service
cp docker.socket /usr/lib/systemd/system/docker.socket
cp containerd.service /usr/lib/systemd/system/containerd.service

systemctl daemon-reload
systemctl start containerd
systemctl start docker.socket
systemctl start docker

systemctl enable containerd
systemctl enable docker.socket
systemctl enable docker

systemctl status containerd docker.socket docker


