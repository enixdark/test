#!/bin/bash

# Copy configuration and JAR files to the appropriate directories
cp jmx/jmx_exporter.yml /opt/kafka/config
cp jmx/jmx_prometheus_javaagent-1.0.1.jar /opt/kafka/bin/

# Create the kafka_runtime.cfg file with necessary configurations
cat <<EOL > /opt/kafka/config/sasl-scram/kafka_runtime.cfg
KAFKA_OPTS="-Djava.security.auth.login.config=/opt/kafka/config/sasl-scram/kafka_server_jaas.conf -javaagent:/opt/kafka/bin/jmx_prometheus_javaagent-1.0.1.jar=5557:/opt/kafka/config/jmx_exporter.yml"
Environment="LOG_DIR=/var/log/kafka"
EOL

# Create the kafka_runtime.cfg file with necessary configurations
cat <<EOL > /opt/kafka/config/kafka_runtime.cfg
KAFKA_OPTS="-javaagent:/opt/kafka/bin/jmx_prometheus_javaagent-1.0.1.jar=5556:/opt/kafka/config/jmx_exporter.yml"
Environment="LOG_DIR=/var/log/kafka"
EOL

# Optionally, uncomment the next line to restart the Kafka service
# systemctl restart kafka

# Restart the Kafka service with SASL authentication
systemctl restart kafka-sasl