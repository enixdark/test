#!/bin/bash

# Check if the user 'quantri' exists
if id "quantri" &>/dev/null; then
    echo "User 'quantri' already exists."
else
    # Add the user 'quantri' if it doesn't exist
    sudo useradd quantri# Add the user 'quantri' without a password
    sudo useradd -m -p "" quantri
    # Lock the account to prevent login until a password is set
    sudo passwd -l quantri
    echo "User 'quantri' has been added."
fi

sudo chown -R quantri:root /opt