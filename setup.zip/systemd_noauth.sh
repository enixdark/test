#!/bin/bash

# Define the source and destination paths
KAFKA_SERVICE_SOURCE="./systemd/kafka.service"
ZK_SERVICE_SOURCE="./systemd/zookeeper.service"
SYSTEMD_PATH="/etc/systemd/system/"

# Function to copy services and start them
copy_and_start_services() {
    echo "Copying Kafka and ZooKeeper service files to systemd..."

    # Copy Kafka service file
    if [[ -f "$KAFKA_SERVICE_SOURCE" ]]; then
        sudo cp "$KAFKA_SERVICE_SOURCE" "$SYSTEMD_PATH"
        echo "Kafka service file copied."
    else
        echo "Kafka service file not found."
        exit 1
    fi

    # Copy ZooKeeper service file
    if [[ -f "$ZK_SERVICE_SOURCE" ]]; then
        sudo cp "$ZK_SERVICE_SOURCE" "$SYSTEMD_PATH"
        echo "ZooKeeper service file copied."
    else
        echo "ZooKeeper service file not found."
        exit 1
    fi

    # Reload systemd to register new service files
    echo "Reloading systemd daemon..."
    sudo systemctl daemon-reload

    # Enable and start the Kafka service
    echo "Starting Kafka service..."
    sudo systemctl enable kafka.service
    sudo systemctl start kafka.service

    # Enable and start the ZooKeeper service
    echo "Starting ZooKeeper service..."
    sudo systemctl enable zookeeper.service
    sudo systemctl start zookeeper.service

    echo "Kafka and ZooKeeper services have been started."
}

# Execute the function
copy_and_start_services