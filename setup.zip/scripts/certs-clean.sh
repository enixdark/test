#!/bin/bash

set -o nounset \
    -o errexit \
    -o verbose
#    -o xtrace

# Cleanup files
cd /tmp/kafka/certs
rm -f *.crt *.csr *_creds *.jks *.srl *.key *.pem *.der *.p12
