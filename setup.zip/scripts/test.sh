# Generate rootCa
openssl genrsa -out rootca.key 4096
openssl req -x509 -new -nodes -key rootca.key -sha256 -days 1000 -out rootca.crt -config rootca.conf
 
 
keytool -keystore kafka.truststore.jks -storetype JKS -import -file 'rootca.crt' -storepass Tpb@123 -alias KMS-RootCA -noprompt
 
# Generate client key
 
NODES=(apkmsnode1-1uv apkmsnode1-2uv apkmsnode1-3uv)
for NODE_NAME in "${NODE[@]}"; do
openssl genrsa -out $NODE_NAME.key 4096
openssl req -new -key $NODE_NAME.key -out $NODE_NAME.csr
openssl x509 -req -in $NODE_NAME.csr -CA rootca.crt -CAkey rootca.key -CAcreateserial -out $NODE_NAME.crt -days 1000 -sha256 -extfile brokercsr.conf -passin pass:Tpb@123
 
 
# Gen keystore for node
keytool -genkeypair -keyalg RSA \
-alias $(hostname --fqdn) \
-keystore $(hostname --fqdn).keystore.jks \
-storepass Tpb@123 \
-keypass Tpb@123 \
-validity 1000 \
-keysize 4096 \
-dname "CN=$(hostname --fqdn), OU=KMS-UAT, O=TPBank, C=VN" \
-ext "san=DNS:$(hostname --fqdn),IP:$(hostname -I | awk '{print $1}')"
 
# Gen CSR
keytool -keystore $(hostname --fqdn).keystore.jks \
-alias $(hostname --fqdn) \
-certreq -file $(hostname --fqdn)_signing_request.csr \
-keypass Tpb@123 \
-storepass Tpb@123
 
# Sign CSR with rootCA
openssl x509 -req -CA rootca.pem  \
-CAkey rootca.key \
-in $(hostname --fqdn)_signing_request.csr \
-out $(hostname --fqdn)_signed \
-days 1000 \
-CAcreateserial \
-passin pass:Tpb@123 \
-extfile configs/brokercsr.conf
 
# Import
keytool -keystore $(hostname --fqdn).keystore.jks \
-trustcacerts \
-alias kms-rootca \
-import -file rootca.pem \
-keypass Tpb@123 \
-storepass Tpb@123 \
-noprompt
 
keytool -keystore $(hostname --fqdn).keystore.jks \
-alias $(hostname --fqdn) \
-import -file $(hostname --fqdn)_signed.pem \
-keypass Tpb@123 \
-storepass Tpb@123 \
-noprompt
 
 
keytool -import -alias kms-rootca -keystore $JAVA_HOME/lib/security/cacerts -file rootca.pem -storepass changeit
 
Shell
/usr/bin/kafka-configs --zookeeper \
    '172.20.20.10:2181,172.20.20.20:2181,172.20.20.30:2181' --alter \
    --add-config 'SCRAM-SHA-256=[password=admin-secret],SCRAM-SHA-512=[password=admin-secret]' \
    --entity-type users --entity-name admin
 
./kafka-configs --zookeeper \
    '10.1.54.105:2182,10.202.14.27:2182,10.6.14.81:2182' --alter \
    --add-config 'SCRAM-SHA-512=[password=DCIT#2023]' \
    --entity-type users --entity-name admin