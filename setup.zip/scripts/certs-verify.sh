#!/bin/bash

set -o nounset \
    -o errexit \
    -o verbose

# See what is in each keystore and truststore
for i in kafka-server-1 kafka-server-2 kafka-server-3
do
        echo "------------------------------- $i keystore -------------------------------"
        keytool -list -v -keystore /tmp/kafka/certs/$i.keystore.jks -storepass Tpb@123 | grep -e Alias -e Entry
        echo "------------------------------- $i truststore -------------------------------"
        keytool -list -v -keystore /tmp/kafka/certs/$i.truststore.jks -storepass Tpb@123 | grep -e Alias -e Entry
done
