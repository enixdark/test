#!/bin/bash

CERTS_FOLDER=/tmp/kafka/certs
DEST_PATH=/opt/kafka/config/sasl-scram/ssl
SERVERS=("kafka-server-1" "kafka-server-2" "kafka-server-3")
IPS=("192.168.56.101" "192.168.56.102" "192.168.56.103")
USER="vagrant"
PASSWORD="your_password_here"

# Loop through the servers and copy the corresponding files
for i in "${!SERVERS[@]}"; do
  SERVER=${SERVERS[$i]}
  IP=${IPS[$i]}

  echo "Copying keystore and truststore for $SERVER to $IP..."

  # sshpass -p "$PASSWORD" scp "$CERTS_FOLDER/$SERVER.keystore.jks" "$USER@$IP:$DEST_PATH/"
  # sshpass -p "$PASSWORD" scp "$CERTS_FOLDER/$SERVER.truststore.jks" "$USER@$IP:$DEST_PATH/"

  scp "$CERTS_FOLDER/$SERVER.keystore.jks" "$USER@$IP:$DEST_PATH/kafka.server.keystore.jks"
  scp "$CERTS_FOLDER/$SERVER.truststore.jks" "$USER@$IP:$DEST_PATH/kafka.server.truststore.jks"

  echo "Keystore and truststore for $SERVER copied to $IP."
done

echo "All files copied successfully."