#!/bin/bash

#set -o nounset \
#    -o errexit \
#    -o verbose \
#    -o xtrace

# Cleanup files 
# rm -f /tmp/kafka/certs/*.crt /tmp/kafka/certs/*.csr /tmp/kafka/certs/*_creds /tmp/kafka/certs/*.jks /tmp/kafka/certs/*.srl /tmp/kafka/certs/*.key /tmp/kafka/certs/*.pem /tmp/kafka/certs/*.der /tmp/kafka/certs/*.p12 /tmp/kafka/certs/extfile

# when have error keytool error: java.io.FileNotFoundException: /usr/lib/security/cacerts (No such file or directory) 
# switch root and use command `cp -r /opt/jres/jdk-11/lib/security /usr/lib`
# then run rm -rf /tmp/kafka/certs

# Set output directory for certificates
CERT_DIR="/tmp/kafka/certs"

# Create the directory if it doesn't exist
mkdir -p $CERT_DIR

# Password for keystore and truststore
PASSWORD="Tpb@123"

# Generate CA key and certificate
echo "Generating CA certificate..."
openssl req -new -x509 -keyout $CERT_DIR/kafka-ca.key -out $CERT_DIR/kafka-ca.crt -days 365 \
  -subj "/CN=KMS-RootCA/OU=KMS-UAT/O=TPBank/L=Hanoi/ST=Ca/C=VN" -passin pass:$PASSWORD -passout pass:$PASSWORD

# Servers to generate certificates for
SERVERS=("kafka-server-1" "kafka-server-2" "kafka-server-3")
IPS=("192.168.56.101" "192.168.56.102" "192.168.56.103")

# Loop over each server and IP to create the keystores, truststores, and certificates
for idx in "${!SERVERS[@]}"; do
    SERVER=${SERVERS[$idx]}
    IP=${IPS[$idx]}

    echo "------------------------------- $SERVER ($IP) -------------------------------"

    # Create server keystore
    keytool -genkey -noprompt \
      -alias $SERVER \
      -dname "CN=$SERVER,OU=KMS-UAT,O=TPBank,L=Hanoi,S=Ca,C=VN" \
      -ext "SAN=dns:$SERVER,dns:localhost,ip:$IP" \
      -keystore $CERT_DIR/$SERVER.keystore.jks \
      -keyalg RSA \
      -storepass $PASSWORD \
      -keypass $PASSWORD \
      -storetype PKCS12

    # Create certificate signing request (CSR)
    keytool -keystore $CERT_DIR/$SERVER.keystore.jks -alias $SERVER -certreq -file $CERT_DIR/$SERVER.csr \
      -storepass $PASSWORD -keypass $PASSWORD -ext "SAN=dns:$SERVER,dns:localhost,ip:$IP"

    # Create configuration file for certificate extensions with both DNS and IP
    cat << EOF > $CERT_DIR/extfile
[req]
distinguished_name = req_distinguished_name
prompt = no
output_password = $PASSWORD
default_bits = 4096
req_extensions = v3_req
x509_extensions = v3_ca

[req_distinguished_name]
C  = VN
O  = TPBank
OU = KMS-UAT
CN = KMS-RootCA

[v3_req]
basicConstraints = CA:FALSE
keyUsage = critical, digitalSignature, keyAgreement
subjectAltName = @alt_names

[alt_names]
DNS.1 = $SERVER
DNS.2 = localhost
IP.1 = $IP
EOF

    # Sign server certificate with CA
    openssl x509 -req -CA $CERT_DIR/kafka-ca.crt -CAkey $CERT_DIR/kafka-ca.key \
      -in $CERT_DIR/$SERVER.csr -out $CERT_DIR/$SERVER-ca1-signed.crt -days 9999 \
      -CAcreateserial -passin pass:$PASSWORD -extensions v3_req -extfile $CERT_DIR/extfile

    # Import CA certificate into keystore
    keytool -noprompt -keystore $CERT_DIR/$SERVER.keystore.jks -alias CARoot -import \
      -file $CERT_DIR/kafka-ca.crt -storepass $PASSWORD -keypass $PASSWORD

    # Import signed server certificate into keystore
    keytool -noprompt -keystore $CERT_DIR/$SERVER.keystore.jks -alias $SERVER -import \
      -file $CERT_DIR/$SERVER-ca1-signed.crt -storepass $PASSWORD -keypass $PASSWORD \
      -ext "SAN=dns:$SERVER,dns:localhost,ip:$IP"

    # Create truststore and import CA certificate
    keytool -noprompt -keystore $CERT_DIR/$SERVER.truststore.jks -alias CARoot -import \
      -file $CERT_DIR/kafka-ca.crt -storepass $PASSWORD -keypass $PASSWORD

    # Save credentials
    echo "$PASSWORD" > $CERT_DIR/${SERVER}_sslkey_creds
    echo "$PASSWORD" > $CERT_DIR/${SERVER}_keystore_creds
    echo "$PASSWORD" > $CERT_DIR/${SERVER}_truststore_creds

    # Export the server certificate in PEM format
    keytool -export -alias $SERVER -file $CERT_DIR/$SERVER.der -keystore $CERT_DIR/$SERVER.keystore.jks -storepass $PASSWORD
    openssl x509 -inform der -in $CERT_DIR/$SERVER.der -out $CERT_DIR/$SERVER.certificate.pem

    # Export the private key from the keystore
    keytool -importkeystore -srckeystore $CERT_DIR/$SERVER.keystore.jks -destkeystore $CERT_DIR/$SERVER.keystore.p12 \
      -deststoretype PKCS12 -deststorepass $PASSWORD -srcstorepass $PASSWORD -noprompt
    openssl pkcs12 -in $CERT_DIR/$SERVER.keystore.p12 -nodes -nocerts -out $CERT_DIR/$SERVER.key -passin pass:$PASSWORD

    # Import the default Java `cacerts` into the truststore
    cacerts_path="$(readlink -f /usr/bin/java | sed "s:bin/java::")lib/security/cacerts"
    keytool -noprompt -destkeystore $CERT_DIR/$SERVER.truststore.jks -importkeystore \
      -srckeystore $cacerts_path -srcstorepass changeit -deststorepass $PASSWORD

    echo "Certificate and keystore generation for $SERVER ($IP) completed."
done
