#!/bin/bash

install_kafka() {
    read -p "Do you want to install Kafka server? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "Start installing Kafka..."

        # Define Kafka home directory
        KAFKA_HOME=/opt/kafka

        # Create Kafka directory if not exists
        mkdir -p /opt/kafka

        # Extract Kafka archive
        tar -xzvf ./kafka_2.12-3.6.1.tgz -C /opt/kafka --strip-components=1

        # Update .bashrc with Kafka environment variables
        source ~/.bashrc
        if ! grep -q "KAFKA_HOME" ~/.bashrc; then
            echo "Updating ~/.bashrc with Kafka environment variables..."
            tee -a ~/.bashrc << END
export KAFKA_HOME=/opt/kafka
export PATH="$KAFKA_HOME/bin:$PATH"
END
        fi

        echo "Kafka installation completed."
    else
        printf "\033[0;31m>> User refused to install Kafka, aborting...\n\033[0m"
        exit 0
    fi
}

# Prerequisite check
printf "\033[0;34mChecking for prerequisites...\n\033[0m"

printf "\033[0;32m>> Kafka Server: \n\033[0m"
if ! kafka-run-class.sh -version; then
    echo -e "\033[0;31mNo Kafka installation found, starting installation...\n\033[0m"
    install_kafka
else
    echo -e "\033[0;32mKafka is already installed.\n\033[0m"
fi