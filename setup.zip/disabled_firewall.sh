#!/bin/bash

systemctl disable firewalld
systemctl stop firewalld